# RickDialogPro — Usage Guide

This guide documents the public usage surface that is currently supported by the RickDialogPro source code.

> [!IMPORTANT]
> Consumer code should use the public `Rick.Dialog.Pro` unit. Units under `Rick.Dialog.Pro.Impl.*` are implementation details and are not required for normal consumption.

## 1. Public API

The public facade is exposed through:

```delphi
uses
  Rick.Dialog.Pro;
```

The facade makes the main public contracts and types available:

- `TRickDialogPro`
- `IRickDialogPro`
- `IRickDialogProTheme`
- `TRickDialogProKind`
- `TRickDialogProResult`
- `TRickDialogProConfig`

A dialog instance can be created with the default theme:

```delphi
var
  LDialog: IRickDialogPro;
begin
  LDialog := TRickDialogPro.New;
end;
```

Or with a custom theme that implements `IRickDialogProTheme`:

```delphi
LDialog := TRickDialogPro.New(LTheme);
```

## 2. Using the Current Source Layout

The current repository includes a FireMonkey example under `source/`.

When the framework is referenced directly from the current source layout, that example uses these Delphi Search Path directories:

```text
src
src\Impl
src\Theme
```

These paths describe the current repository organization. They are not a statement about every possible future distribution mechanism.

## 3. Keeping a Dialog Instance

The example included in the repository keeps an `IRickDialogPro` reference in the form:

```delphi
private
  FDialog: IRickDialogPro;
```

and creates the instance when the form is initialized:

```delphi
procedure TPageMain.FormCreate(Sender: TObject);
begin
  FDialog := TRickDialogPro.New;
end;
```

The interface reference can then be reused for multiple dialog calls.

## 4. Information

**Verified behavior:** `Information` is part of the current `IRickDialogPro` contract. Its default primary caption is `Entendi`, and the secondary caption defaults to an empty string.

```delphi
var
  LResult: TRickDialogProResult;
begin
  LResult := FDialog.Information(
    'Information',
    'The data was updated.'
  );
end;
```

A custom primary caption can also be supplied:

```delphi
FDialog.Information(
  'Information',
  'The data was updated.',
  'OK'
);
```

## 5. Success

**Verified behavior:** `Success` is part of the current contract. Its default primary caption is `Concluir`.

```delphi
FDialog.Success(
  'Success',
  'The operation was completed.'
);
```

With a custom caption:

```delphi
FDialog.Success(
  'Success',
  'The operation was completed.',
  'Close'
);
```

## 6. Warning

**Verified behavior:** `Warning` is part of the current contract. Its default primary caption is `Entendi`.

```delphi
FDialog.Warning(
  'Attention',
  'Review the data before continuing.'
);
```

It can also expose a secondary action:

```delphi
FDialog.Warning(
  'Confirmation',
  'Do you want to continue?',
  'Continue',
  'Cancel'
);
```

## 7. Error

**Verified behavior:** `Error` is part of the current contract. Its default primary caption is `Fechar`.

```delphi
FDialog.Error(
  'Error',
  'The operation could not be completed.'
);
```

With custom captions:

```delphi
FDialog.Error(
  'Error',
  'The operation could not be completed.',
  'Retry',
  'Close'
);
```

## 8. Custom Action Captions

The semantic helper methods accept the following arguments:

```text
Title
MessageText
PrimaryCaption
SecondaryCaption
```

`PrimaryCaption` and `SecondaryCaption` allow the consuming application to define the text shown to the user.

Example:

```delphi
FDialog.Warning(
  'Delete item',
  'Do you want to delete the selected item?',
  'Delete',
  'Keep'
);
```

The captions describe presentation. The meaning of each returned action remains the responsibility of the consuming application.

## 9. Handling Results

The public result type is:

```delphi
TRickDialogProResult = (
  None,
  Primary,
  Secondary
);
```

### Primary and Secondary

**Verified behavior:** clicking the primary action records `Primary`; clicking the secondary action records `Secondary`.

```delphi
var
  LResult: TRickDialogProResult;
begin
  LResult := FDialog.Warning(
    'Confirmation',
    'Do you want to continue?',
    'Continue',
    'Cancel'
  );

  case LResult of
    TRickDialogProResult.Primary:
      begin
        { Application-defined primary action. }
      end;

    TRickDialogProResult.Secondary:
      begin
        { Application-defined secondary action. }
      end;

    TRickDialogProResult.None:
      begin
        { No Primary or Secondary action was recorded. }
      end;
  end;
end;
```

### None

**Verified behavior:** the runtime dialog initializes its result as `None`. The value is changed only when a recognized primary or secondary action is recorded, and `Execute` returns the current result after the modal interaction ends.

Therefore, the supported statement is:

> `None` means that no `Primary` or `Secondary` action was recorded before the modal execution ended.

The current code does **not** justify assigning a specific closing mechanism to `None`. This guide therefore does not claim, for example, that `None` specifically means Escape, window close, or any other particular action.

## 10. Business Rules Stay in the Application

RickDialogPro returns which action was selected. It does not execute application business rules.

Example:

```delphi
var
  LResult: TRickDialogProResult;
begin
  LResult := FDialog.Warning(
    'Delete record',
    'Do you want to delete this record?',
    'Delete',
    'Cancel'
  );

  case LResult of
    TRickDialogProResult.Primary:
      DeleteRecord;

    TRickDialogProResult.Secondary:
      Exit;
  end;
end;
```

In this example, `DeleteRecord` belongs to the consuming application. RickDialogPro only reports the selected action.

`Primary` does not universally mean "Yes", and `Secondary` does not universally mean "Cancel". Their business meaning depends on the captions and the consuming code.

## 11. Execute with TRickDialogProConfig

In addition to the four semantic helper methods, `IRickDialogPro` exposes:

```delphi
function Execute(
  const AConfig: TRickDialogProConfig
): TRickDialogProResult;
```

A configuration can be created with one of the existing builders:

```delphi
var
  LConfig: TRickDialogProConfig;
  LResult: TRickDialogProResult;
begin
  LConfig := TRickDialogProConfig.Warning(
    'Confirmation',
    'Do you want to continue?',
    'Continue',
    'Cancel'
  );

  LResult := FDialog.Execute(LConfig);
end;
```

This is useful when the application needs to prepare the configuration before showing the dialog.

## 12. Configuration Builders

`TRickDialogProConfig` currently provides these builders:

```delphi
TRickDialogProConfig.Error(...)
TRickDialogProConfig.Warning(...)
TRickDialogProConfig.Information(...)
TRickDialogProConfig.Success(...)
```

**Verified behavior:** each builder:

1. starts from `TRickDialogProConfig.Default`;
2. applies the requested semantic kind;
3. assigns the title, message and captions;
4. sets `ShowSecondary` according to whether the trimmed secondary caption is empty;
5. preserves `UseBackground` as `False`, as defined by `TRickDialogProConfig.Default`.

For example:

```delphi
LConfig := TRickDialogProConfig.Success(
  'Completed',
  'The operation finished successfully.',
  'Finish'
);
```

If the secondary caption is omitted or blank after trimming, the builder sets `ShowSecondary` to `False`.

## 13. Manual Configuration

Manual configuration is possible because the configuration record exposes its fields publicly.

The default configuration is:

| Field | Current default |
|---|---|
| `Kind` | `Information` |
| `Title` | empty |
| `MessageText` | empty |
| `PrimaryCaption` | `Entendi` |
| `SecondaryCaption` | empty |
| `ShowSecondary` | `False` |
| `UseBackground` | `False` |

Example with one action:

```delphi
var
  LConfig: TRickDialogProConfig;
begin
  LConfig := TRickDialogProConfig.Default;

  LConfig.Kind := TRickDialogProKind.Information;
  LConfig.Title := 'Information';
  LConfig.MessageText := 'The process is ready.';
  LConfig.PrimaryCaption := 'OK';

  FDialog.Execute(LConfig);
end;
```

Example with a secondary action:

```delphi
var
  LConfig: TRickDialogProConfig;
begin
  LConfig := TRickDialogProConfig.Default;

  LConfig.Kind := TRickDialogProKind.Warning;
  LConfig.Title := 'Confirmation';
  LConfig.MessageText := 'Do you want to continue?';
  LConfig.PrimaryCaption := 'Yes';
  LConfig.SecondaryCaption := 'No';
  LConfig.ShowSecondary := True;

  FDialog.Execute(LConfig);
end;
```

> [!IMPORTANT]
> **Verified behavior:** in the current runtime implementation, the secondary button is created only when `ShowSecondary` is `True` **and** `SecondaryCaption` is not empty after trimming.
>
> When configuration is built manually, set both values consistently. The existing configuration builders already calculate `ShowSecondary` from the secondary caption.

### Using the Theme Background

**Verified behavior:** `UseBackground` is `False` by default. When it remains disabled, the RuntimeForm keeps the current transparent `Fill.Color` behavior. When `UseBackground` is `True`, the RuntimeForm assigns `IRickDialogProTheme.Background` to the host form's `Fill.Color`.

```delphi
var
  LConfig: TRickDialogProConfig;
begin
  LConfig := TRickDialogProConfig.Information(
    'Information',
    'The host form will use the Background provided by the theme.'
  );

  LConfig.UseBackground := True;

  FDialog.Execute(LConfig);
end;
```

The `Error`, `Warning`, `Information`, and `Success` helpers keep the default behavior because their builders start from `TRickDialogProConfig.Default`, where `UseBackground` is `False`. To enable the theme background through the current API, use `TRickDialogProConfig` and `Execute`.

> [!NOTE]
> The current code proves that, when enabled, `FTheme.Background` is assigned to the RuntimeForm `Fill.Color`. Because `Transparency` remains `True`, this guide does not claim additional visual effects beyond that assignment without specific visual validation.

## 14. Custom Themes

The public facade accepts a custom `IRickDialogProTheme`:

```delphi
FDialog := TRickDialogPro.New(LTheme);
```

A custom theme should implement the complete current interface.

### Illustrative example

> [!NOTE]
> The color values below are **illustrative only**. They demonstrate how to implement the public theme contract and inject the implementation into `TRickDialogPro.New`. They are not a required or recommended RickDialogPro palette.

```delphi
uses
  Rick.Dialog.Pro,
  System.UITypes;

type
  TMyDialogTheme = class(TInterfacedObject, IRickDialogProTheme)
  public
    function Background: TAlphaColor;
    function Surface: TAlphaColor;
    function SurfaceElevated: TAlphaColor;
    function Border: TAlphaColor;
    function TextPrimary: TAlphaColor;
    function TextSecondary: TAlphaColor;

    function StatusColor(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function IconBackground(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function IconStroke(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function PrimaryButtonBackground(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function PrimaryButtonHoverBackground(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function PrimaryButtonText(
      AKind: TRickDialogProKind
    ): TAlphaColor;

    function SecondaryButtonBackground: TAlphaColor;
    function SecondaryButtonHoverBackground: TAlphaColor;
    function SecondaryButtonText: TAlphaColor;
  end;

function TMyDialogTheme.Background: TAlphaColor;
begin
  Result := TAlphaColor($FF101418);
end;

function TMyDialogTheme.Surface: TAlphaColor;
begin
  Result := TAlphaColor($FF1C2228);
end;

function TMyDialogTheme.SurfaceElevated: TAlphaColor;
begin
  Result := TAlphaColor($FF252D35);
end;

function TMyDialogTheme.Border: TAlphaColor;
begin
  Result := TAlphaColor($FF3A4652);
end;

function TMyDialogTheme.TextPrimary: TAlphaColor;
begin
  Result := TAlphaColor($FFF5F7FA);
end;

function TMyDialogTheme.TextSecondary: TAlphaColor;
begin
  Result := TAlphaColor($FFB5C0CB);
end;

function TMyDialogTheme.StatusColor(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  case AKind of
    TRickDialogProKind.Error:
      Result := TAlphaColor($FFE05252);

    TRickDialogProKind.Warning:
      Result := TAlphaColor($FFE0A52B);

    TRickDialogProKind.Information:
      Result := TAlphaColor($FF4C9BE8);

    TRickDialogProKind.Success:
      Result := TAlphaColor($FF42A66B);
  else
    Result := TAlphaColor($FF4C9BE8);
  end;
end;

function TMyDialogTheme.IconBackground(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  Result := StatusColor(AKind);
end;

function TMyDialogTheme.IconStroke(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  Result := TAlphaColor($FFFFFFFF);
end;

function TMyDialogTheme.PrimaryButtonBackground(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  Result := StatusColor(AKind);
end;

function TMyDialogTheme.PrimaryButtonHoverBackground(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  Result := StatusColor(AKind);
end;

function TMyDialogTheme.PrimaryButtonText(
  AKind: TRickDialogProKind
): TAlphaColor;
begin
  Result := TAlphaColor($FFFFFFFF);
end;

function TMyDialogTheme.SecondaryButtonBackground: TAlphaColor;
begin
  Result := TAlphaColor($FF303942);
end;

function TMyDialogTheme.SecondaryButtonHoverBackground: TAlphaColor;
begin
  Result := TAlphaColor($FF3B4651);
end;

function TMyDialogTheme.SecondaryButtonText: TAlphaColor;
begin
  Result := TAlphaColor($FFF5F7FA);
end;
```

The theme can then be injected through the public facade:

```delphi
var
  LTheme: IRickDialogProTheme;
begin
  LTheme := TMyDialogTheme.Create;
  FDialog := TRickDialogPro.New(LTheme);
end;
```

### Background and `UseBackground`

`Background` is part of the current `IRickDialogProTheme` contract and must be implemented by a custom theme.

**Verified behavior:** the RuntimeForm queries `IRickDialogProTheme.Background` only when `TRickDialogProConfig.UseBackground` is `True`. When `UseBackground` remains `False`, the default behavior keeps the transparent `Fill.Color`.

The option is enabled through dialog configuration, not through an additional parameter on `Error`, `Warning`, `Information`, or `Success`.

> [!NOTE]
> In the current implementation, `Transparency` remains `True`. The documentation therefore strictly describes the assignment of `Background` to `Fill.Color` when enabled and does not presume a visual result beyond what the code validates.

### Theme methods used by the current runtime implementation

| Theme method | Current runtime usage |
|---|---|
| `Background` | Used when `TRickDialogProConfig.UseBackground = True`; with `False`, the default transparent behavior remains |
| `Surface` | Used |
| `SurfaceElevated` | Used |
| `Border` | Used |
| `TextPrimary` | Used |
| `TextSecondary` | Used |
| `StatusColor` | Used |
| `IconBackground` | Used |
| `IconStroke` | Used |
| `PrimaryButtonBackground` | Used |
| `PrimaryButtonHoverBackground` | Used |
| `PrimaryButtonText` | Used |
| `SecondaryButtonBackground` | Used |
| `SecondaryButtonHoverBackground` | Used |
| `SecondaryButtonText` | Used |

## 15. Repository Example

The current example under `source/` demonstrates basic consumption with the default theme.

Its form keeps:

```delphi
FDialog: IRickDialogPro;
```

creates it with:

```delphi
FDialog := TRickDialogPro.New;
```

and calls the four semantic helpers:

```delphi
FDialog.Error(...);
FDialog.Warning(...);
FDialog.Information(...);
FDialog.Success(...);
```

The current example does not establish that every API capability is demonstrated there. In particular, this guide does not use the example project as evidence for custom themes or automated regression testing.

## 16. Quick API Reference

### TRickDialogPro

```delphi
class function New: IRickDialogPro; overload; static;

class function New(
  const ATheme: IRickDialogProTheme
): IRickDialogPro; overload; static;
```

### IRickDialogPro

```delphi
function Execute(
  const AConfig: TRickDialogProConfig
): TRickDialogProResult;

function Error(
  const ATitle: string;
  const AMessageText: string;
  const APrimaryCaption: string = 'Fechar';
  const ASecondaryCaption: string = ''
): TRickDialogProResult;

function Warning(
  const ATitle: string;
  const AMessageText: string;
  const APrimaryCaption: string = 'Entendi';
  const ASecondaryCaption: string = ''
): TRickDialogProResult;

function Information(
  const ATitle: string;
  const AMessageText: string;
  const APrimaryCaption: string = 'Entendi';
  const ASecondaryCaption: string = ''
): TRickDialogProResult;

function Success(
  const ATitle: string;
  const AMessageText: string;
  const APrimaryCaption: string = 'Concluir';
  const ASecondaryCaption: string = ''
): TRickDialogProResult;
```

### TRickDialogProKind

```delphi
TRickDialogProKind = (
  Error,
  Warning,
  Information,
  Success
);
```

### TRickDialogProResult

```delphi
TRickDialogProResult = (
  None,
  Primary,
  Secondary
);
```

### TRickDialogProConfig

Public fields:

```delphi
Kind: TRickDialogProKind;
Title: string;
MessageText: string;
PrimaryCaption: string;
SecondaryCaption: string;
ShowSecondary: Boolean;
UseBackground: Boolean;
```

Available builders:

```delphi
TRickDialogProConfig.Default
TRickDialogProConfig.Error(...)
TRickDialogProConfig.Warning(...)
TRickDialogProConfig.Information(...)
TRickDialogProConfig.Success(...)
```

## 17. Current Implementation Notes

The following distinctions are intentional in this guide:

- **Verified behavior** is stated directly when it is supported by the current code.
- **Illustrative examples** are identified explicitly when values are chosen only to demonstrate API usage.
- **Current implementation cautions** are stated explicitly when documentation must limit a claim to what the code actually proves.

Relevant current behavior:

- `TRickDialogProConfig.UseBackground` is `False` by default.
- When `UseBackground = True`, the RuntimeForm assigns `IRickDialogProTheme.Background` to `Fill.Color`.
- `Transparency` remains `True`; therefore the guide does not extrapolate this into unvalidated visual effects.

This guide does not claim build, platform, or automated-test results that were not actually produced.
